import IUser from "./user.interface";
import IRole from "./role.interface";
export { IUser, IRole };
